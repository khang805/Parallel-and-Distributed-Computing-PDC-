#!/usr/bin/env python3
"""
Memory-efficient PSAIIM for Higgs Dataset using NetworkX
- Streams edgelists directly into integer-node graphs
- Interns node IDs as ints (no Python strings)
- Avoids large intermediate lists
"""
import os
import time
import gc
import networkx as nx
from collections import defaultdict, deque
from concurrent.futures import ThreadPoolExecutor

# Parallelism
MAX_WORKERS = 4

# Filenames (full dataset)
SOCIAL_FILE  = 'higgs-social_network.edgelist'
REPLY_FILE   = 'higgs-reply_network.edgelist'
RETWEET_FILE = 'higgs-retweet_network.edgelist'
MENTION_FILE = 'higgs-mention_network.edgelist'
ACTIVITY_FILE= 'higgs-activity_time.txt'

# Utility: stream an edgelist into a DiGraph with int IDs
def load_int_graph(path, directed=True):
    G = nx.DiGraph() if directed else nx.Graph()
    with open(path) as f:
        for line in f:
            u_str, v_str = line.split()[:2]
            try:
                u = int(u_str)
                v = int(v_str)
            except ValueError:
                # fallback: hash strings to ints
                u = hash(u_str)
                v = hash(v_str)
            G.add_edge(u, v)
    return G

# Stream activity: build interest sets and action counts
def load_activity(path):
    interest = defaultdict(set)
    action_counts = defaultdict(int)
    with open(path) as f:
        for line in f:
            parts = line.split()
            if len(parts) < 4:
                continue
            u_str, v_str, ts, action = parts[:4]
            try:
                u = int(u_str)
                v = int(v_str)
            except ValueError:
                u = hash(u_str); v = hash(v_str)
            interest[u].add(action)
            action_counts[(u, v, action)] += 1
    return interest, action_counts

# SCC partition + level assignment
def scc_partition(G):
    sccs = list(nx.strongly_connected_components(G))
    node_to_scc = {n:i for i, comp in enumerate(sccs) for n in comp}
    S = len(sccs)
    dag = nx.DiGraph()
    dag.add_nodes_from(range(S))
    for u, v in G.edges():
        i, j = node_to_scc[u], node_to_scc[v]
        if i != j:
            dag.add_edge(i, j)
    levels = {}
    # BFS from roots
    roots = [n for n in dag if dag.in_degree(n)==0]
    q = deque((r,1) for r in roots)
    seen = set()
    while q:
        comp, lvl = q.popleft()
        if comp in seen: continue
        seen.add(comp)
        levels[comp] = lvl
        for nbr in dag.successors(comp):
            q.append((nbr, lvl+1))
    for comp in dag:
        levels.setdefault(comp, 1)
    comm_by_level = defaultdict(list)
    for comp, lvl in levels.items():
        comm_by_level[lvl].append(comp)
    return sccs, node_to_scc, comm_by_level

# Influence calculation (PageRank-like)
def calc_influence(G, action_counts, interest, iterations=5, damping=0.85):
    inf = {n:1.0 for n in G.nodes()}
    factors = {'RT':0.5,'RE':0.3,'MT':0.2}
    N = G.number_of_nodes()
    for _ in range(iterations):
        new_inf = {}
        for n in G:
            total = 0.0
            for p in G.predecessors(n):
                sim = 0.5
                ivp = interest.get(p)
                ivn = interest.get(n)
                if ivp and ivn:
                    inter = ivp & ivn; union = ivp | ivn
                    sim = len(inter)/len(union) if union else 0.5
                w = sum(factors[a]*action_counts.get((p,n,a),0) for a in factors)
                total += (w * sim * inf[p]) / max(1, G.out_degree(p))
            new_inf[n] = damping*total + (1-damping)*(G.in_degree(n)/max(1,N))
        inf = new_inf
    return inf

# Seed candidate selection
def select_candidates(inf, decay=0.9):
    I_star = set()
    for n, val in inf.items():
        thresh = val
        L = 1
        while thresh > val*(decay**L):
            L+=1
        if val > thresh:
            I_star.add(n)
    return I_star

# BFS tree builder
def bfs_tree(G, root):
    T = nx.DiGraph(); seen={root}; dq=deque([root])
    while dq:
        u=dq.popleft()
        for v in G.successors(u):
            if v not in seen:
                seen.add(v); T.add_edge(u,v); dq.append(v)
    return T

# Final seed selection
def select_seeds(G, I_star, inf):
    seeds=set()
    trees={u:bfs_tree(G,u) for u in I_star}
    while I_star:
        u_max = max(I_star, key=lambda x: trees[x].number_of_nodes())
        group = [v for v in trees[u_max] if v in I_star]
        if not group: break
        pr={v:nx.pagerank(trees[v])[v] for v in group}
        v_min=min(pr,key=pr.get)
        seeds.add(v_min)
        I_star -= set(group)|{v_min}
    return seeds

# Process one level
def process_level(sccs, comps, G, inf):
    out=[]
    for cid in comps:
        nodes=sccs[cid]
        local_inf={n:inf.get(n,0) for n in nodes}
        I_star=select_candidates(local_inf)
        seeds=select_seeds(G.subgraph(nodes), I_star, inf)
        if seeds: out.append(next(iter(seeds)))
    return out

# Main
if __name__=='__main__':
    start=time.time()
    # 1. load social
    print("Loading social graph...")
    G_social = load_int_graph(SOCIAL_FILE)
    print(f"Social: {G_social.number_of_nodes()} nodes, {G_social.number_of_edges()} edges")
    # 2. partition
    print("Partitioning SCCs...")
    sccs,node2scc,comm_by_lvl=scc_partition(G_social)
    gc.collect()
    # 3. load activity
    print("Loading activity...")
    interest,action_counts=load_activity(ACTIVITY_FILE)
    # 4. build behavior
    print("Building behavior graph...")
    G_beh = load_int_graph(RETWEET_FILE)
    for f in (REPLY_FILE,MENTION_FILE):
        G_beh.add_edges_from(load_int_graph(f).edges())
    print(f"Behavior: {G_beh.number_of_nodes()} nodes, {G_beh.number_of_edges()} edges")
    # 5. influence
    print("Calculating influence...")
    inf=calc_influence(G_beh,action_counts,interest)
    del G_beh, action_counts, interest; gc.collect()
    # 6. seed per level
    print("Selecting seeds per level...")
    results={}
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
        for lvl in sorted(comm_by_lvl):
            fut=ex.submit(process_level, sccs, comm_by_lvl[lvl], G_social, inf)
            results[lvl]=fut.result()
    # 7. output
    print("\n=== Seeds by Level ===")
    for lvl,seeds in results.items(): print(f"Level {lvl}: {seeds}")
    print(f"Done in {time.time()-start:.2f}s")

