#!/usr/bin/env python3
"""
Optimized Memory-efficient PSAIIM for p2p-Gnutella04 with Beautified Output
- Shows levels with communities
- Displays most influential nodes per community
- Provides clear seed node selection
"""
import os
import time
import gc
import random
import networkx as nx
import numpy as np
from collections import defaultdict, deque
from concurrent.futures import ProcessPoolExecutor
from tabulate import tabulate  # For prettier table output

# Configuration
MAX_WORKERS = os.cpu_count() // 2 or 1
P2P_FILE = 'p2p-Gnutella04.txt'
MAX_ITERATIONS = 50
CONVERGENCE_THRESHOLD = 1e-4
BATCH_SIZE = 250

# Algorithm parameters
ALPHA = {'RT': 0.50, 'RE': 0.35, 'MT': 0.15}
DAMPING = 0.85

# Visualization settings
TERMINAL_WIDTH = 80
SEPARATOR = "=" * TERMINAL_WIDTH

def print_header(title):
    """Print a nicely formatted header"""
    print("\n" + SEPARATOR)
    print(f" {title} ".center(TERMINAL_WIDTH, "="))
    print(SEPARATOR)

def load_graph(path):
    """Load graph with efficient node relabeling"""
    print(f"Loading {path}...")
    try:
        G = nx.read_edgelist(path, comments='#', create_using=nx.DiGraph, nodetype=int)
        G = nx.convert_node_labels_to_integers(G)
        print(f"Loaded {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
        return G
    except FileNotFoundError:
        print(f"Error: File {path} not found!")
        exit(1)

def generate_synthetic_data(G):
    """Generate synthetic interactions with vectorized operations"""
    print("Generating synthetic data...")
    edges = list(G.edges())
    
    # Vectorized probability checks
    rt_mask = np.random.random(len(edges)) < 0.3
    re_mask = np.random.random(len(edges)) < 0.2
    mt_mask = np.random.random(len(edges)) < 0.1
    
    # Build interaction graphs
    G_rt = nx.DiGraph()
    G_re = nx.DiGraph()
    G_mt = nx.DiGraph()
    
    for i, (u, v) in enumerate(edges):
        if rt_mask[i]:
            G_rt.add_edge(u, v, weight=np.random.uniform(0.5, 2.0))
        if re_mask[i]:
            G_re.add_edge(u, v, weight=np.random.uniform(0.3, 1.5))
        if mt_mask[i]:
            G_mt.add_edge(u, v, weight=np.random.uniform(0.2, 1.0))
    
    print(f"retweet network: {G_rt.number_of_edges()} edges")
    print(f"reply network: {G_re.number_of_edges()} edges")
    print(f"mention network: {G_mt.number_of_edges()} edges")
    
    return G_rt, G_re, G_mt

def compute_scc_levels(G):
    """Compute SCC levels with optimized DAG processing"""
    print_header("COMMUNITY DETECTION (SCC/CAC PARTITIONING)")
    print("Computing strongly connected components and levels...")
    
    sccs = list(nx.strongly_connected_components(G))
    print(f"Found {len(sccs)} strongly connected components")
    
    # Map nodes to their SCC ID
    node_scc = {n: i for i, comp in enumerate(sccs) for n in comp}
    
    # Build condensed DAG
    cdag = nx.condensation(G, sccs)
    level_map = {}
    
    # Assign levels using topological sort
    for node in nx.topological_sort(cdag):
        pred_levels = [level_map.get(p, 0) for p in cdag.predecessors(node)]
        level_map[node] = max(pred_levels, default=0) + 1
    
    # Map components to levels
    scc_levels = defaultdict(list)
    for comp, level in level_map.items():
        scc_levels[level].append(comp)
    
    # Display community structure
    print("\nCommunity Structure Summary:")
    level_data = []
    for level, comps in sorted(scc_levels.items()):
        total_nodes = sum(len(sccs[comp]) for comp in comps)
        level_data.append([level, len(comps), total_nodes])
    
    print(tabulate(level_data, 
                   headers=["Level", "Communities", "Total Nodes"],
                   tablefmt="pretty"))
    
    return sccs, node_scc, scc_levels

def precompute_weights(G, interactions):
    """Precompute all edge weights with proper aggregation"""
    print("Precomputing edge weights...")
    edge_weights = defaultdict(float)
    
    # Aggregate weights from interaction graphs
    for (u, v), data in interactions.items():
        edge_weights[(u, v)] += data['weight']
    
    # Ensure non-zero weights for edges in G
    for u, v in G.edges():
        if (u, v) not in edge_weights:
            edge_weights[(u, v)] = 1e-6  # Small default weight to avoid zero
    
    return edge_weights

def calculate_influence(G, interactions, scc_data):
    """Parallel influence calculation with batched processing"""
    print_header("INFLUENCE POWER CALCULATION")
    sccs, node_scc, scc_levels = scc_data
    
    # Precompute edge weights
    edge_weights = precompute_weights(G, interactions)
    
    # Initialize influence scores with small random variations
    influence = np.random.uniform(0.9, 1.1, G.number_of_nodes())
    influence /= influence.sum()  # Normalize initially
    
    # Process levels in reverse topological order
    total_levels = len(scc_levels)
    print(f"Processing {total_levels} levels in parallel...")
    
    for level_idx, level in enumerate(sorted(scc_levels.keys(), reverse=True)):
        print(f"Processing level {level} ({level_idx+1}/{total_levels})...")
        components = scc_levels[level]
        
        # Batch components for parallel processing
        batches = [components[i:i+BATCH_SIZE] for i in range(0, len(components), BATCH_SIZE)]
        
        with ProcessPoolExecutor(max_workers=MAX_WORKERS) as executor:
            futures = []
            for batch in batches:
                futures.append(executor.submit(
                    process_batch,
                    G, edge_weights, sccs, node_scc, influence.copy(), batch
                ))
            
            # Aggregate influence scores
            new_influence = np.zeros_like(influence)
            counts = np.zeros_like(influence)
            
            for future in futures:
                batch_results = future.result()
                for n, score in batch_results.items():
                    idx = n  # Assuming nodes are integers matching indices
                    new_influence[idx] += score
                    counts[idx] += 1
            
            # Average scores for nodes processed multiple times
            mask = counts > 0
            new_influence[mask] /= counts[mask]
            influence[mask] = new_influence[mask]
    
    # Final normalization
    influence /= influence.sum()
    return dict(zip(G.nodes(), influence))

def process_batch(G, edge_weights, sccs, node_scc, influence, components):
    """Process a batch of components in parallel"""
    local_influence = influence.copy()
    node_index = {n: i for i, n in enumerate(G.nodes())}
    
    for comp_id in components:
        nodes = sccs[comp_id]
        if not nodes:
            continue
        
        # Create subgraph and index mapping
        subgraph = G.subgraph(nodes)
        node_map = {n: i for i, n in enumerate(nodes)}
        size = len(nodes)
        
        # Initialize matrices
        M = np.zeros((size, size))
        damping = np.full(size, (1 - DAMPING) / size)
        
        # Build transition matrix
        for i, u in enumerate(nodes):
            successors = list(subgraph.successors(u))
            total_weight = sum(edge_weights.get((u, v), 0) for v in successors)
            
            if not successors or total_weight == 0:
                # For nodes with no successors, distribute influence to all nodes in component
                M[:, i] = 1 / size
                continue
                
            for v in successors:
                j = node_map[v]
                weight = edge_weights.get((u, v), 1e-6)
                M[j, i] = weight / total_weight
        
        # Power iteration with convergence check
        scores = np.array([local_influence[node_index[n]] for n in nodes])
        for _ in range(MAX_ITERATIONS):
            new_scores = DAMPING * (M @ scores) + damping
            if np.linalg.norm(new_scores - scores, ord=np.inf) < CONVERGENCE_THRESHOLD:
                break
            scores = new_scores
        
        # Update local influence scores
        for i, n in enumerate(nodes):
            local_influence[node_index[n]] = scores[i]
    
    return {n: local_influence[i] for i, n in enumerate(G.nodes())}

def get_community_influential_nodes(sccs, influence, top_n=3):
    """Find the most influential nodes for each community"""
    print(f"Showing some influential nodes for the communities:")
    
    # Get largest communities (top 10)
    largest_comps = sorted([(i, len(comp)) for i, comp in enumerate(sccs)], 
                           key=lambda x: x[1], reverse=True)[:10]
    
    for comp_id, size in largest_comps:
        # Skip tiny communities
        if size < 3:
            continue
            
        # Get top influential nodes in this community
        community_nodes = list(sccs[comp_id])
        top_nodes = sorted([(n, influence[n]) for n in community_nodes], 
                           key=lambda x: x[1], reverse=True)[:top_n]
        
        # Display as table
        node_data = [[i+1, node, f"{score:.6f}"] for i, (node, score) in enumerate(top_nodes)]
        print(tabulate(node_data, 
                       headers=["Rank", "Node", "Influence Score"],
                       tablefmt="pretty"))

def select_seeds(influence, G, sccs, node_scc, k=10):
    """Select seeds using efficient greedy approach with community awareness"""
    print_header("SEED SELECTION")
    print(f"Selecting {k} seed nodes having same influence score using community-aware greedy algorithm...")
    
    # Get top candidates (3x the number of seeds we want)
    nodes = list(G.nodes())
    scores = [influence[n] for n in nodes]
    
    # Get candidates from top nodes and largest communities
    candidate_set = set()
    
    # Add top influential nodes overall
    top_indices = np.argsort(scores)[-k*3:]
    candidate_set.update(nodes[i] for i in top_indices)
    
    # Add top nodes from largest communities
    largest_comps = sorted([(i, len(comp)) for i, comp in enumerate(sccs)], 
                           key=lambda x: x[1], reverse=True)[:5]
    
    for comp_id, _ in largest_comps:
        community_nodes = list(sccs[comp_id])
        top_nodes = sorted([(n, influence[n]) for n in community_nodes], 
                           key=lambda x: x[1], reverse=True)[:3]
        candidate_set.update(node for node, _ in top_nodes)
    
    # Greedy selection with coverage and diversity
    selected = []
    covered = set()
    communities_covered = set()
    
    for _ in range(k):
        best = None
        best_score = -1
        
        for node in candidate_set:
            if node in covered:
                continue
                
            # Estimate coverage (1-hop and 2-hop neighbors)
            neighbors_1hop = set(G.successors(node)) | set(G.predecessors(node))
            neighbors_2hop = set()
            for neighbor in neighbors_1hop:
                neighbors_2hop.update(G.successors(neighbor))
                neighbors_2hop.update(G.predecessors(neighbor))
            
            new_coverage = len((neighbors_1hop | neighbors_2hop) - covered)
            
            # Community diversity bonus
            community = node_scc.get(node, -1)
            comm_bonus = 2 if community not in communities_covered else 1
            
            # Influence score bonus
            inf_score = influence[node] * 100  # Scale up
            
            # Combined score
            score = new_coverage * comm_bonus * inf_score
            
            if score > best_score:
                best = node
                best_score = score
                
        if best is None:
            break
            
        # Add the selected node
        selected.append(best)
        
        # Update covered nodes
        neighbors_1hop = set(G.successors(best)) | set(G.predecessors(best))
        covered.update(neighbors_1hop)
        
        # Update covered communities
        communities_covered.add(node_scc.get(best, -1))
    
    return selected

def main():
    start = time.time()
    
    print_header("PSAIIM ALGORITHM FOR P2P-GNUTELLA04")
    print(f"Using {MAX_WORKERS} parallel workers")
    
    # Load and prepare data
    G = load_graph(P2P_FILE)
    G_rt, G_re, G_mt = generate_synthetic_data(G)
    
    # Compute SCC levels
    scc_data = compute_scc_levels(G)
    sccs, node_scc, scc_levels = scc_data
    
    # Combine interactions
    interactions = defaultdict(dict)
    for u, v, data in G_rt.edges(data=True):
        interactions[(u, v)]['weight'] = data['weight'] * ALPHA['RT']
    for u, v, data in G_re.edges(data=True):
        interactions[(u, v)]['weight'] = data['weight'] * ALPHA['RE']
    for u, v, data in G_mt.edges(data=True):
        interactions[(u, v)]['weight'] = data['weight'] * ALPHA['MT']
    
    # Calculate influence
    influence = calculate_influence(G, interactions, scc_data)
    
    # Show most influential nodes per community
    get_community_influential_nodes(sccs, influence)
    
    # Select seeds
    k = 10  # Number of seeds to select
    seeds = select_seeds(influence, G, sccs, node_scc, k)
    
    # Display final seed selections
    print("\nFinal Seed Node Selection:")
    seed_data = []
    
    for i, seed in enumerate(seeds):
        community_id = node_scc.get(seed, -1)
        community_size = len(sccs[community_id]) if community_id >= 0 else 0
        neighbors = len(set(G.successors(seed)) | set(G.predecessors(seed)))
        
        seed_data.append([
            i+1, 
            seed, 
            f"{influence[seed]:.6f}", 
            community_id,
            community_size,
            neighbors
        ])
    
    print(tabulate(seed_data, 
                   headers=["#", "Node", "Influence Score", "Community", "Comm. Size", "Neighbors"],
                   tablefmt="pretty"))
    
    # Show execution time
    elapsed = time.time() - start
    print(f"\nTotal execution time: {elapsed:.2f} seconds")

if __name__ == "__main__":
    main()
