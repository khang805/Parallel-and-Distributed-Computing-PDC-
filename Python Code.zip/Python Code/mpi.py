#!/usr/bin/env python3
"""
Optimized MPI+OpenMP PSAIIM for p2p-Gnutella04
- Uses MPI for distributed processing between nodes
- Uses METIS for balanced graph partitioning
- Uses ThreadPoolExecutor to simulate OpenMP-style threading
- Shows communities organized by level
- Displays influential nodes and combines seed selections
"""
import os
import time
import gc
import random
import networkx as nx
import numpy as np
from collections import defaultdict, deque
from mpi4py import MPI
from concurrent.futures import ThreadPoolExecutor
# Try to import METIS for balanced partitioning; fallback if unavailable
try:
    import metis
    HAVE_METIS = True
except ImportError:
    HAVE_METIS = False
    if MPI.COMM_WORLD.Get_rank() == 0:
        print("[WARNING] python-metis not installed; falling back to simple partitioning")

# Initialize MPI
comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

# Configuration
OMP_THREADS = int(os.getenv('OMP_NUM_THREADS', max(1, os.cpu_count() // 2)))
P2P_FILE = 'p2p-Gnutella04.txt'
MAX_ITERATIONS = 50
CONVERGENCE_THRESHOLD = 1e-4
BATCH_SIZE = 250

# Algorithm parameters
ALPHA = {'RT': 0.50, 'RE': 0.35, 'MT': 0.15}
DAMPING = 0.85

# Visualization settings
TERMINAL_WIDTH = 80
SEPARATOR = "=" * TERMINAL_WIDTH

def print_header(title):
    print("\n" + SEPARATOR)
    node_type = "MASTER" if rank == 0 else f"WORKER {rank}"
    print(f" {title} [{node_type}] ".center(TERMINAL_WIDTH, "="))
    print(SEPARATOR)

# -- Graph loading and METIS partitioning --

def load_graph(path):
    print(f"[Node {rank}] Loading {path}...")
    try:
        G = nx.read_edgelist(path, comments='#', create_using=nx.DiGraph, nodetype=int)
        G = nx.convert_node_labels_to_integers(G)
        print(f"[Node {rank}] Loaded {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
        return G
    except FileNotFoundError:
        print(f"Error: File {path} not found!")
        comm.Abort(1)


def partition_graph_metis(G):
    """Partition graph using METIS if available, else simple split"""
    print_header("GRAPH PARTITIONING")
    nodes = list(G.nodes())
    n = len(nodes)
    if HAVE_METIS:
        G_und = G.to_undirected()
        edgecuts, parts = metis.part_graph(G_und, nparts=size)
        my_nodes = [n for n,p in zip(G_und.nodes(), parts) if p == rank]
    else:
        # simple balanced split by index
        per = n // size
        start = rank * per
        end = start + per if rank < size-1 else n
        my_nodes = nodes[start:end]
    sub = G.subgraph(my_nodes).copy()
    print(f"[Node {rank}] Subgraph: {sub.number_of_nodes()} nodes, {sub.number_of_edges()} edges")
    return sub

# -- Synthetic data generation (threaded) --

def process_edge(chunk):
    rt, re, mt = [], [], []
    for u, v in chunk:
        r = random.random()
        if r < 0.3: rt.append((u, v, {'weight': random.uniform(0.5,2.0)}))
        if r < 0.5: re.append((u, v, {'weight': random.uniform(0.3,1.5)}))
        if r < 0.6: mt.append((u, v, {'weight': random.uniform(0.2,1.0)}))
    return rt, re, mt


def generate_synthetic_data(G):
    print(f"[Node {rank}] Generating synthetic interactions...")
    edges = list(G.edges())
    if not edges:
        return nx.DiGraph(), nx.DiGraph(), nx.DiGraph(), {}
    chunk_size = max(1, len(edges) // OMP_THREADS)
    chunks = [edges[i:i+chunk_size] for i in range(0, len(edges), chunk_size)]
    rt_edges, re_edges, mt_edges = [], [], []
    with ThreadPoolExecutor(max_workers=OMP_THREADS) as exec:
        for rt, re, mt in exec.map(process_edge, chunks):
            rt_edges.extend(rt); re_edges.extend(re); mt_edges.extend(mt)
    G_rt, G_re, G_mt = nx.DiGraph(), nx.DiGraph(), nx.DiGraph()
    G_rt.add_edges_from(rt_edges); G_re.add_edges_from(re_edges); G_mt.add_edges_from(mt_edges)
    print(f"[Node {rank}] RT:{G_rt.number_of_edges()} RE:{G_re.number_of_edges()} MT:{G_mt.number_of_edges()}")
    return G_rt, G_re, G_mt, None

# -- SCC and community levels --

def compute_scc_levels(G):
    print_header("COMMUNITY DETECTION (SCC)")
    sccs = list(nx.strongly_connected_components(G))
    node_to_scc = {n:i for i, comp in enumerate(sccs) for n in comp}
    cdag = nx.condensation(G, sccs)
    level_map = {}
    for n in nx.topological_sort(cdag):
        preds = [level_map.get(p,0) for p in cdag.predecessors(n)]
        level_map[n] = max(preds, default=0) + 1
    levels = defaultdict(list)
    for comp, lvl in level_map.items(): levels[lvl].append(comp)
    print(f"[Node {rank}] {len(sccs)} SCCs over {len(levels)} levels")
    return sccs, node_to_scc, levels

# -- Edge weight precompute (threaded) --

def compute_weight_for_chunk(chunk, G_rt, G_re, G_mt):
    partial = {}
    for u, v in chunk:
        w=0.0
        if G_rt.has_edge(u,v): w+=ALPHA['RT']*G_rt[u][v]['weight']
        if G_re.has_edge(u,v): w+=ALPHA['RE']*G_re[u][v]['weight']
        if G_mt.has_edge(u,v): w+=ALPHA['MT']*G_mt[u][v]['weight']
        partial[(u,v)] = w if w>0 else 1e-6
    return partial


def precompute_weights(G, G_rt, G_re, G_mt):
    print(f"[Node {rank}] Precomputing weights...")
    edges = list(G.edges())
    chunk = max(1, len(edges)//OMP_THREADS)
    chunks = [edges[i:i+chunk] for i in range(0, len(edges), chunk)]
    weights = {}
    with ThreadPoolExecutor(max_workers=OMP_THREADS) as exec:
        for part in exec.map(lambda c: compute_weight_for_chunk(c, G_rt, G_re, G_mt), chunks):
            weights.update(part)
    return weights

# -- Influence calc per SCC level (threaded) --

def process_comp_data(data):
    G, comp, sccs, infl, weights = data
    nodes = list(sccs[comp])
    idx = {n:i for i,n in enumerate(nodes)}
    M = np.zeros((len(nodes),len(nodes)))
    for i,u in enumerate(nodes):
        succ=[v for v in G.successors(u) if v in idx]
        if not succ: M[:,i]=1/len(nodes)
        else:
            tot=sum(weights[(u,v)] for v in succ)
            for v in succ: M[idx[v],i]=weights[(u,v)]/tot
    scores = np.array([infl[n] for n in nodes])
    damp = (1-DAMPING)/len(nodes)
    for _ in range(MAX_ITERATIONS):
        new = DAMPING*(M@scores)+damp
        if np.linalg.norm(new-scores,np.inf)<CONVERGENCE_THRESHOLD: break
        scores=new
    return {n: scores[idx[n]] for n in nodes}


def calculate_influence(G, scc_data, G_rt, G_re, G_mt):
    print_header("INFLUENCE CALCULATION")
    sccs, node_to_scc, levels = scc_data
    weights = precompute_weights(G, G_rt, G_re, G_mt)
    infl={n:1/G.number_of_nodes() for n in G.nodes()}
    for lvl in sorted(levels.keys(), reverse=True):
        comps=levels[lvl]
        data=[(G,c,sccs,infl.copy(),weights) for c in comps]
        with ThreadPoolExecutor(max_workers=OMP_THREADS) as exec:
            for res in exec.map(process_comp_data, data): infl.update(res)
    total=sum(infl.values()); infl={n:v/total for n,v in infl.items()}
    return infl

# -- Seed selection --

def select_seeds(G, infl, k=10):
    print_header("SEED SELECTION")
    seeds=[n for n,_ in sorted(infl.items(), key=lambda x:x[1],reverse=True)[:k]]
    print(f"[Node {rank}] Seeds: {seeds}")
    return seeds

# -- Main workflow --

def main():
    # Record start time
    start_time = time.time()
    if rank == 0:
        print_header("MPI+OpenMP PSAIIM")
    comm.Barrier()
    G_full = load_graph(P2P_FILE)
    G = partition_graph_metis(G_full)
    G_rt, G_re, G_mt, _ = generate_synthetic_data(G)
    scc_data = compute_scc_levels(G)
    infl = calculate_influence(G, scc_data, G_rt, G_re, G_mt)
    seeds_local = select_seeds(G, infl, k=10)
    all_seeds = comm.gather(seeds_local, root=0)
    if rank == 0:
        print_header("COMBINED SEEDS")
        for r, seeds in enumerate(all_seeds):
            print(f"Node {r}: {seeds}")
        # Print execution time
        elapsed = time.time() - start_time
        print(f"Total execution time: {elapsed:.2f} seconds")

if __name__ == "__main__":
    main()

